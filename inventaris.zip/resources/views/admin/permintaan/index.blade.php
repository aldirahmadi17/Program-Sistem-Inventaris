<x-app-layout>
    <x-slot name="title">Daftar Permintaan Barang</x-slot>

    <x-alert-error></x-alert-error>

    @if(session()->has('success'))
    <x-alert type="success" message="{{ session()->get('success') }}" />
    @endif

    <x-card>
        <x-slot name="title">Daftar Permintaan Barang</x-slot>
        <x-slot name="option">
            <button class="btn btn-primary add"><i class="fas fa-plus"></i> Tambah Permintaan Barang</button>
        </x-slot>

        <table class="table table-hover mb-3">
            <thead>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Deskripsi</th>
                <th>Tanggal Permintaan</th>
                <th>Status</th>
                <th></th>
            </thead>
            <tbody>
                @foreach ($requestItems as $requestItem)
                    <tr>
                        <td>{{ $requestItem->name }}</td>
                        <td>{{ $requestItem->quantity }}</td>
                        <td>{{ $requestItem->description }}</td>
                        <td>{{ $requestItem->created_at->format('d-m-Y') }}</td>
                        <td>{{ $requestItem->status }}</td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-primary edit" data-id="{{ $requestItem->id }}"><i class="fas fa-edit"></i></button>
                            @if($requestItem->status == 'pending' && (auth()->user()->hasRole('Admin') || auth()->user()->hasRole('gudang')))
                                <form action="{{ route('admin.request-items.approve', $requestItem->id) }}" method="POST" style="display: inline-block;">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Approve</button>
                                </form>
                            @endif
                            <form action="{{ route('admin.request-items.destroy', $requestItem->id) }}" style="display: inline-block;" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn-sm btn-danger delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </x-card>

    {{-- Add Modal --}}
    <x-modal>
        <x-slot name="title">
            <h6 class="m-0 font-weight-bold text-primary">Tambah Permintaan Barang</h6>
        </x-slot>
        <x-slot name="id">add</x-slot>

        <form action="{{ route('admin.request-items.store') }}" method="post" class="form-group">
            @csrf
            <div class="form-group">
                <label for="">Nama:</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">Jumlah:</label>
                <input type="number" name="quantity" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">Deskripsi:</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </x-modal>

    {{-- Edit Modal --}}
    <x-modal>
        <x-slot name="title">
            <h6 class="m-0 font-weight-bold text-primary">Edit Permintaan Barang</x-slot>
        <x-slot name="id">edit</x-slot>

        <form action="{{ route('admin.request-items.update') }}" method="post" id="edit" class="form-group">
            @csrf
            @method('PUT')
            <input type="hidden" name="id">
            <div class="form-group">
                <label for="">Nama:</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">Jumlah:</label>
                <input type="number" name="quantity" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="">Deskripsi:</label>
                <textarea name="description" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </x-modal>

    <x-slot name="script">
        <script>
            $('.add').click(function() {
                $('#add').modal('show');
            });

            $('.edit').click(function() {
                const id = $(this).data('id');
                // Add your logic to populate the edit form with the item's data
                $('#edit').modal('show');
            });

            $('.delete').click(function(e){
                e.preventDefault();
                Swal.fire({
                    title: 'Ingin menghapus?',
                    text: 'Data akan dihapus permanen',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Hapus',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $(this).parent().submit();
                    }
                });
            });

            // Approve form submission with confirmation
            $('form').on('submit', function(e) {
                var form = this;
                e.preventDefault();
                Swal.fire({
                    title: 'Ingin menyetujui permintaan ini?',
                    text: 'Permintaan akan disetujui',
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText: 'Setujui',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        </script>
    </x-slot>
</x-app-layout>
