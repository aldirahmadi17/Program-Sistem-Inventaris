<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use App\Models\Barang;
use App\Models\BarangMasuk;
use App\Models\Laporan;
use Illuminate\Http\Request;
use App\Http\Requests\BarangMasukRequest;

class BarangMasukController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:gudang', [
            'only' => ['index', 'store', 'info', 'update', 'destroy']
        ]);
    }

    public function index(BarangMasuk $barang_masuk)
    {
        $supplier = Supplier::select('nama', 'id')->get();
        $barang = Barang::select('nama', 'id', 'kode')->latest()->get();
        $data = $barang_masuk->with('supplier', 'barang')->get();

        return view('admin.barang-masuk.index', compact('data', 'supplier', 'barang'));
    }

    public function store(BarangMasukRequest $request)
    {
        $barang_masuk = BarangMasuk::create($request->all());
        Barang::find($request->barang_id)->increment('jumlah', $request->jumlah);

        // Create report
        Laporan::create([
            'nama' => $barang_masuk->barang->nama,
            'orang' => $barang_masuk->supplier->nama,
            'jumlah' => $request->jumlah,
            'jenis' => 'Barang Masuk',
            'root_id' => $barang_masuk->id
        ]);

        return back()->with('success', 'Barang berhasil ditambahkan');
    }

    public function info(Request $request)
    {
        $barang_masuk = BarangMasuk::with('supplier', 'barang')->findOrFail($request->id);
        return $barang_masuk;
    }

    public function update(BarangMasukRequest $request)
    {
        $barang_masuk = BarangMasuk::findOrFail($request->id);

        $jumlah = $request->jumlah - $barang_masuk->jumlah;

        $barang_masuk->update($request->all());

        // Update report
        Laporan::where('jenis', 'Barang Masuk')
            ->where('root_id', $barang_masuk->id)
            ->update([
                'nama' => $barang_masuk->barang->nama,
                'orang' => $barang_masuk->supplier->nama,
                'jumlah' => $request->jumlah,
                'jenis' => 'Barang Masuk'
            ]);

        // Update stock
        if ($barang_masuk->barang) {
            $barang_masuk->barang->increment('jumlah', $jumlah);
        }

        return back()->with('success', 'Stok barang berhasil diperbarui');
    }

    public function destroy($id)
    {
        $barang_masuk = BarangMasuk::findOrFail($id);

        // Decrease stock
        if ($barang_masuk->barang) {
            $barang_masuk->barang->decrement('jumlah', $barang_masuk->jumlah);
        }

        // Delete report
        Laporan::where('jenis', 'Barang Masuk')->where('root_id', $barang_masuk->id)->delete();

        // Delete item
        $barang_masuk->delete();

        return back()->with('success', 'Barang berhasil dihapus');
    }
}