<?php

namespace App\Http\Controllers;

use App\Models\{Barang, Gudang};
use Illuminate\Http\Request;
use App\Http\Requests\BarangRequest;

class BarangController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:gudang', [
            'only' => ['index','store', 'info', 'update', 'destroy']
        ]);
    }
    
    public function index(Barang $barang)
    {
        $gudang = Gudang::all();
        $data = null;
        
        // Default gudang to ICT if no filter is applied
        if (request()->has('filter_gudang')) {
            $data = $barang->where('gudang_id', request('filter_gudang'))->get();
        } else {
            $gudangICT = Gudang::where('nama', 'ICT')->first();
            if ($gudangICT) {
                $data = $barang->where('gudang_id', $gudangICT->id)->get();
            } else {
                $data = $barang->all(); // Fallback to all items if ICT gudang not found
            }
        }
        
        return view('admin.barang.index', compact('data', 'gudang'));
    }
    

    public function store(Barang $barang, Gudang $gudang, BarangRequest $request)
    {
        $totalBarang = Barang::count();
        $newNumber = $totalBarang + 1;
        $kode = 'BR/' . str_pad($newNumber, 3, '0', STR_PAD_LEFT) . '/2024';

        $newBarang = $barang->create(array_merge($request->all(), ['kode' => $kode]));

        return back()->with('success', 'Barang berhasil ditambahkan dengan kode: ' . $newBarang->kode);
    }

    public function info(Barang $barang)
    {
        $data = $barang->find(request('id'));
        $gudang = Gudang::find($data->gudang_id);
        return [
            'barang' => $data,
            'gudang' => [
                'id' => $gudang->id,
                'nama' => $gudang->nama
            ]
        ];
    }

    public function update(Barang $barang, BarangRequest $request)
    {
        $barang->find($request->id)->update($request->all());
        return back();
    }

    public function destroy(Barang $barang, $id)
    {
        $data = $barang->find($id);
        $data->delete();
        return back();
    }

    public function masuk(Request $request)
    {
        $barang = Barang::findOrFail($request->barang_id);
        $jumlah_masuk = $request->jumlah_masuk;

        $barang->stock += $jumlah_masuk;
        $barang->save();

        return back()->with('success', 'Jumlah barang masuk berhasil diperbarui');
    }

    public function keluar(Request $request)
    {
        $barang = Barang::findOrFail($request->barang_id);
        $jumlah_keluar = $request->jumlah_keluar;

        if ($barang->stock >= $jumlah_keluar) {
            $barang->stock -= $jumlah_keluar;
            $barang->save();

            return back()->with('success', 'Jumlah barang keluar berhasil diperbarui');
        } else {
            return back()->with('error', 'Jumlah barang keluar melebihi stok yang tersedia');
        }
    }
}