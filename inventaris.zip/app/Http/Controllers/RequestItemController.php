<?php

namespace App\Http\Controllers;

use App\Models\RequestItem;
use Illuminate\Http\Request;
use App\Http\Requests\RequestItemRequest;
use Illuminate\Support\Facades\Notification;
use App\Notifications\ItemApprovedNotification;
use App\Models\User; // Add this import

class RequestItemController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:gudang|barang', [
            'only' => ['index', 'store', 'show', 'edit', 'update', 'destroy']
        ]);
        $this->middleware('permission:Admin|gudang', [
            'only' => ['approve']
        ]);
    }

    public function index()
    {
        $requestItems = RequestItem::latest()->get();
        return view('admin.permintaan.index', compact('requestItems'));
    }

    public function store(RequestItemRequest $request)
    {
        $requestData = $request->validated();
        $requestItem = RequestItem::create($requestData);
        return redirect()->route('admin.request-items.index')->with('success', 'Request item created successfully.');
    }

    public function show(RequestItem $requestItem)
    {
        return view('admin.request-items.show', compact('requestItem'));
    }

    public function edit(RequestItem $requestItem)
    {
        return view('admin.request-items.edit', compact('requestItem'));
    }

    public function update(RequestItemRequest $request, RequestItem $requestItem)
    {
        $requestData = $request->validated();
        $requestItem->update($requestData);
        return redirect()->route('admin.request-items.index')->with('success', 'Request item updated successfully.');
    }

    public function destroy(RequestItem $requestItem)
    {
        $requestItem->delete();
        return redirect()->route('admin.request-items.index')->with('success', 'Request item deleted successfully.');
    }

    public function approve(RequestItem $requestItem)
    {
        if ($requestItem->status === 'pending') {
            $requestItem->update(['status' => 'approved']);
            // Get staff users with the 'barang' permission or role
            $StaffBarang = User::permission('barang')->get();
            Notification::send($StaffBarang, new ItemApprovedNotification($requestItem));
            return redirect()->route('admin.request-items.index')->with('success', 'Request item approved successfully.');
        }

        return redirect()->route('admin.request-items.index')->with('error', 'Request item is not in a pending state.');
    }
}
