<button class="btn btn-<?php echo e($type); ?> mt-3" type="<?php echo e(($for) ?? 'button'); ?>">
	<?php echo e($text); ?>

</button><?php /**PATH /home/muhammadarif/Documents/abangarif/Inventaris-Barang/Sistem-Inventaris-Barang/resources/views/components/button.blade.php ENDPATH**/ ?>