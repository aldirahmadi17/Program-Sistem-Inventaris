<button class="btn btn-<?php echo e($type); ?> mt-3" type="<?php echo e(($for) ?? 'button'); ?>">
	<?php echo e($text); ?>

</button><?php /**PATH C:\Users\Administrator\Documents\Sistem-Inventaris-Barang\resources\views/components/button.blade.php ENDPATH**/ ?>