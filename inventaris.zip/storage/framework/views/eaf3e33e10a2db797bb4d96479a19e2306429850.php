<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
        <div class="sidebar-brand-icon">
            <img src="<?php echo e(asset((setting('logo')) ? '/storage/'.setting('logo') : 'dist/img/logo/pertamina.jpg')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3">Logistik</div>
    </a>
    <hr class="sidebar-divider my-0">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Dashboard','icon' => 'tachometer-alt','url' => ''.e(route('admin.dashboard')).'','active' => ''.e(request()->routeIs('admin.dashboard') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Dashboard','icon' => 'tachometer-alt','url' => ''.e(route('admin.dashboard')).'','active' => ''.e(request()->routeIs('admin.dashboard') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('member-list')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Daftar Petugas','icon' => 'users','url' => ''.e(route('admin.member')).'','active' => ''.e(request()->routeIs('admin.member') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Daftar Petugas','icon' => 'users','url' => ''.e(route('admin.member')).'','active' => ''.e(request()->routeIs('admin.member') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
    
    <hr class="sidebar-divider mb-0">

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('gudang')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Daftar Gudang','icon' => 'th','url' => ''.e(route('admin.gudang.index')).'','active' => ''.e(request()->routeIs('admin.gudang.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Daftar Gudang','icon' => 'th','url' => ''.e(route('admin.gudang.index')).'','active' => ''.e(request()->routeIs('admin.gudang.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manager')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Laporan','icon' => 'file','url' => ''.e(route('admin.laporan.index')).'','active' => ''.e(request()->routeIs('admin.laporan.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Laporan','icon' => 'file','url' => ''.e(route('admin.laporan.index')).'','active' => ''.e(request()->routeIs('admin.laporan.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('barang')): ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Daftar Barang','icon' => 'box','url' => ''.e(route('admin.barang.index')).'','active' => ''.e(request()->routeIs('admin.barang.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Daftar Barang','icon' => 'box','url' => ''.e(route('admin.barang.index')).'','active' => ''.e(request()->routeIs('admin.barang.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Barang Masuk','icon' => 'sign-in-alt','url' => ''.e(route('admin.barang-masuk.index')).'','active' => ''.e(request()->routeIs('admin.barang-masuk.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Barang Masuk','icon' => 'sign-in-alt','url' => ''.e(route('admin.barang-masuk.index')).'','active' => ''.e(request()->routeIs('admin.barang-masuk.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Barang Keluar','icon' => 'sign-out-alt','url' => ''.e(route('admin.barang-keluar.index')).'','active' => ''.e(request()->routeIs('admin.barang-keluar.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Barang Keluar','icon' => 'sign-out-alt','url' => ''.e(route('admin.barang-keluar.index')).'','active' => ''.e(request()->routeIs('admin.barang-keluar.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Permintaan Barang','icon' => 'sign-in-alt','url' => ''.e(route('admin.request-items.index')).'','active' => ''.e(request()->routeIs('admin.request-items.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Permintaan Barang','icon' => 'sign-in-alt','url' => ''.e(route('admin.request-items.index')).'','active' => ''.e(request()->routeIs('admin.request-items.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.nav-link','data' => ['text' => 'Daftar Supplier','icon' => 'users','url' => ''.e(route('admin.supplier.index')).'','active' => ''.e(request()->routeIs('admin.supplier.index') ? ' active' : '').'']]); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['text' => 'Daftar Supplier','icon' => 'users','url' => ''.e(route('admin.supplier.index')).'','active' => ''.e(request()->routeIs('admin.supplier.index') ? ' active' : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <hr class="sidebar-divider mb-0">
    <?php endif; ?>
</ul><?php /**PATH /home/muhammadarif/Documents/Sistem-Inventaris-Barang/resources/views/components/sidebar.blade.php ENDPATH**/ ?>