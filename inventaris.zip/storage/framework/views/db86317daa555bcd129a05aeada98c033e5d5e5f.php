<div class="alert alert-<?php echo e($type); ?>">
	<?php echo e($message); ?>

</div><?php /**PATH /home/muhammadarif/Documents/abangarif/Inventaris-Barang/Sistem-Inventaris-Barang/resources/views/components/alert.blade.php ENDPATH**/ ?>