<button class="btn btn-<?php echo e($type); ?> mt-3" type="<?php echo e(($for) ?? 'button'); ?>">
	<?php echo e($text); ?>

</button><?php /**PATH /home/muhammadarif/Documents/Sistem-Inventaris-Barang/resources/views/components/button.blade.php ENDPATH**/ ?>