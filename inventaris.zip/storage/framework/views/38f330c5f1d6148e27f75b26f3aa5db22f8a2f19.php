<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title', null, []); ?> Daftar Barang Masuk <?php $__env->endSlot(); ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert-error','data' => []]); ?>
<?php $component->withName('alert-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
	<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> Semua Barang Masuk <?php $__env->endSlot(); ?>
		 <?php $__env->slot('option', null, []); ?> 
			<button class="btn btn-primary add"><i class="fas fa-plus"></i> Tambah Stok Barang</button>
		 <?php $__env->endSlot(); ?>

		<table class="table table-hover mb-3">
			<thead>
				<th>Supplier</th>
				<th>Nama Barang</th>
				<th>Harga</th>
				<th>Stok</th>
				<th>Berat</th>
				<th>Tgl Masuk</th>
				<th></th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($row->supplier->nama); ?></td>
						<td><?php echo e($row->barang->nama); ?></td>
						<td><?php echo e($row->harga); ?></td>
						<td><?php echo e($row->jumlah); ?></td>
						<td><?php echo e($row->berat); ?>kg</td>
						<td><?php echo e($row->created_at->format('d-m-Y')); ?></td>
						<td class="text-center">
							<button class="btn btn-sm btn-primary edit" data-id="<?php echo e($row->id); ?>"><i class="fas fa-edit"></i></button>
							<form action="<?php echo e(route('admin.barang-masuk.destroy', $row->id)); ?>" style="display: inline-block;" method="POST">
							<?php echo csrf_field(); ?>
							<button type="button" class="btn btn-sm btn-danger delete"><i class="fas fa-trash"></i></button>
						</form>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tbody>
		</table>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> 
			<h6 class="m-0 font-weight-bold text-primary">Tambahkan yang masuk</h6>
		 <?php $__env->endSlot(); ?>
		 <?php $__env->slot('id', null, []); ?> add <?php $__env->endSlot(); ?>


		<form action="<?php echo e(route('admin.barang-masuk.store')); ?>" method="post" class="form-group">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Supplier</label>
						<select name="supplier_id" class="form-control">
							<option value="">-- Pilih Supplier --</option>
							<?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Barang</label>
						<select name="barang_id" class="form-control">
							<option value="">-- Pilih Barang --</option>
							<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Stok</label>
						<input type="number" value="0" class="form-control" name="jumlah">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Berat (kg)</label>
						<input type="number" value="0" class="form-control" name="berat">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Harga</label>
						<input type="text" placeholder="Rp. 0" class="form-control harga" name="harga">
					</div>
				</div>
			</div>
			<div class="form-group">
				<textarea name="catatan" id="" cols="30" rows="10" class="form-control" placeholder="Catatan"></textarea>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> 
			<h6 class="m-0 font-weight-bold text-primary">Edit Stok</h6>
		 <?php $__env->endSlot(); ?>
		 <?php $__env->slot('id', null, []); ?> edit <?php $__env->endSlot(); ?>


		<form action="<?php echo e(route('admin.barang-masuk.update')); ?>" method="post" id="edit" class="form-group">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="id">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Supplier</label>
						<select name="supplier_id" class="form-control">
							<option value="">-- Pilih Supplier --</option>
							<?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Barang</label>
						<select name="barang_id" class="form-control">
							<option value="">-- Pilih Barang --</option>
							<?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Stok</label>
						<input type="number" value="0" class="form-control" name="jumlah">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Berat (kg)</label>
						<input type="number" value="0" class="form-control" name="berat">
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="">Harga</label>
						<input type="text" placeholder="Rp. 0" class="form-control harga" name="harga">
					</div>
				</div>
			</div>
			<div class="form-group">
				<textarea name="catatan" id="" cols="30" rows="10" class="form-control" placeholder="Catatan"></textarea>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	

	 <?php $__env->slot('script', null, []); ?> 
		<script src="<?php echo e(asset('dist/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/js/simple.money.format.js')); ?>"></script>
		<script>
			$('.harga').simpleMoneyFormat();

			$('.add').click(function() {
				$('#add').modal('show')
			})

			$('.edit').click(function() {
				const id = $(this).data('id')

				$.get(`<?php echo e(route('admin.barang-masuk.info')); ?>?id=${id}`, function(data) {
					$('#edit input[name="id"]').val(id)

					$(`#edit select[name="supplier_id"] option[value="${data.supplier.id}"]`).attr('selected', 'true')
					$(`#edit select[name="barang_id"] option[value="${data.barang.id}"]`).attr('selected', 'true')
					$('#edit input[name="jumlah"]').val(data.jumlah)
					$('#edit input[name="berat"]').val(data.berat)
					$('#edit input[name="harga"]').val(data.harga)
					$('#edit textarea[name="catatan"]').val(data.catatan)
				})

				$('#edit').modal('show')
			})

			$('.delete').click(function(e){
				e.preventDefault()
				Swal.fire({
				  title: 'Ingin menghapus?',
				  text: 'Data akan dihapus permanen',
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonText: 'Hapus',
				  cancelButtonText: 'Batal'
				}).then((result) => {
					if (result.isConfirmed) {
				  		$(this).parent().submit()
					} 
				})

			})

			$(document).ready(function () {
		      $('table').DataTable();
		    });
		</script>
	 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Administrator\Documents\Sistem-Inventaris-Barang\resources\views/admin/barang-masuk/index.blade.php ENDPATH**/ ?>